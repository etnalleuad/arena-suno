# SONG_STATE — паспорт одной песни

- SONG_ID:
- Название:
- Дата/версия паспорта:
- Stage: idea / generation / stems / arrangement / repair / mix / final
- Творческая цель:
- Активный жанр:
- Не менять:
- Избегать:
- BPM: unknown
- BPM source/confidence:
- Meter:
- First downbeat/time origin:
- Key: unknown
- Key source/confidence:
- Voice: собственный Verified Voice
- Voice profile name (если известен):
- Model / version:
- UI controls actually available:
- Current settings:
- Approved reference/takes:
- Audio/files actually attached in THIS chat:
- Local library assets available but not attached:
- Track map (name → Audio/MIDI → musical role):
- Selected target / time range:
- Existing FX / automation:
- Budget / stop rule:
- External material rights status:
- Last accepted change:
- Rejected changes and why:
- Remaining problems:
- Next ONE action:

## Approved filenames
Записывать реальные имена, не шаблонные выдумки. Учитывать version/date.

## Journal
Дата | операция | source | range | prompt/version | settings | цена | обе версии проверены? | решение

## Handoff
Что другому чату обязательно знать для продолжения без догадок:
