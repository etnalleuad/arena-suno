# Добавить мой материал в реестр

Предложи новый USER_ID, не меняя D/F/N/L/S/M/R IDs исходной библиотеки.
Filename:
Локальная папка:
URL / pack / publisher:
Тип и роль:
Что мне нравится в звуке (моё прослушивание):
Чего не хочу:
BPM / key / root / duration:
Источник этих значений: publisher / filename / measured / unknown
License URL / document stored locally:
Licensed/downloaded: yes / no / unknown
AI-source allowed: explicit permission / local-only / unknown
Intended use:
Файл прикреплён в этот чат: yes / no

Для Splice стандартный default — не AI-source; не объявлять разрешение только на основании royalty-free. PDF лицензии с личными данными хранить осознанно, не в публичном shared Gem.
